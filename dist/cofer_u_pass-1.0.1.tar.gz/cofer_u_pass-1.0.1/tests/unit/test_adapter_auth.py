from __future__ import annotations

import pytest

from cofer_u_pass.adapters.registry import AdapterRegistry


class FakeLocator:
    def __init__(self, visible: bool):
        self._visible = visible

    async def count(self) -> int:
        return 1 if self._visible else 0

    @property
    def first(self):
        return self

    async def is_visible(self) -> bool:
        return self._visible


class FakePage:
    def __init__(self, visible_selectors: set[str], visible_roles: set[tuple[str, str | None]] | None = None):
        self.visible_selectors = visible_selectors
        self.visible_roles = visible_roles or set()

    def locator(self, value: str) -> FakeLocator:
        return FakeLocator(value in self.visible_selectors)

    def get_by_role(self, value: str, *, name=None, exact=False) -> FakeLocator:
        return FakeLocator((value, name) in self.visible_roles)

    def get_by_label(self, value: str, *, exact=False) -> FakeLocator:
        return FakeLocator(False)

    def get_by_placeholder(self, value: str, *, exact=False) -> FakeLocator:
        return FakeLocator(False)

    def get_by_text(self, value: str, *, exact=False) -> FakeLocator:
        return FakeLocator(False)


@pytest.mark.asyncio
async def test_chatgpt_guest_composer_is_not_treated_as_authenticated():
    adapter = AdapterRegistry().create("chatgpt")
    page = FakePage({"#prompt-textarea", "a[href*='/auth/login']"})
    assert await adapter.is_authenticated(page) is False


@pytest.mark.asyncio
async def test_chatgpt_composer_without_explicit_logged_out_signal_can_authenticate():
    adapter = AdapterRegistry().create("chatgpt")
    page = FakePage({"#prompt-textarea"})
    assert await adapter.is_authenticated(page) is True
