import json
from pathlib import Path


def test_required_versioned_schemas_exist_and_parse():
    root = Path(__file__).parents[2] / "schemas"
    expected = {
        "protocol-v1.schema.json", "event-v1.schema.json", "canonical-block-v1.schema.json",
        "adapter-rules-v1.schema.json", "adapter-manifest-v1.schema.json", "config-v1.schema.json", "run-v1.schema.json",
    }
    assert expected <= {p.name for p in root.glob("*.json")}
    for name in expected:
        assert isinstance(json.loads((root / name).read_text(encoding="utf-8")), dict)
