from __future__ import annotations

from cofer_u_pass.domain.models import Block


def block_to_text(block: Block) -> str:
    if block.type in {"text", "paragraph", "heading", "code", "unknown"} and block.text:
        own = block.text
    elif block.type == "link" and block.text:
        own = block.text
    else:
        own = ""
    children = "\n".join(filter(None, (block_to_text(child) for child in block.children)))
    if own and children:
        return f"{own}\n{children}"
    return own or children


def block_to_markdown(block: Block) -> str:
    if block.type == "document":
        return "\n\n".join(filter(None, (block_to_markdown(c) for c in block.children)))
    if block.type == "heading":
        return f"{'#' * (block.level or 1)} {block.text or ''}".rstrip()
    if block.type == "paragraph":
        if block.children:
            return "".join(block_to_markdown(c) for c in block.children)
        return block.text or ""
    if block.type == "text":
        return block.text or ""
    if block.type == "code":
        lang = block.language or ""
        return f"```{lang}\n{block.text or ''}\n```"
    if block.type == "blockquote":
        content = "\n".join(block_to_markdown(c) for c in block.children) or (block.text or "")
        return "\n".join(f"> {line}" for line in content.splitlines())
    if block.type == "list":
        ordered = bool(block.attrs.get("ordered"))
        lines: list[str] = []
        for i, child in enumerate(block.children, start=1):
            content = block_to_markdown(child).strip()
            prefix = f"{i}. " if ordered else "- "
            lines.append(prefix + content.replace("\n", "\n  "))
        return "\n".join(lines)
    if block.type == "list_item":
        return " ".join(filter(None, (block_to_markdown(c).strip() for c in block.children))) or (block.text or "")
    if block.type == "link":
        return f"[{block.text or block.href or ''}]({block.href or ''})"
    if block.type == "image":
        return f"![{block.text or ''}]({block.href or ''})"
    if block.type == "thematic_break":
        return "---"
    if block.children:
        return "\n".join(block_to_markdown(c) for c in block.children)
    return block.text or ""
