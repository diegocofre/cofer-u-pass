# Validation Report — v1.0.2

Validation date: 2026-07-26

## Completed in this build environment

- Deterministic/unit/contract/integration tests: 26 passed, 2 skipped. Coverage includes ChatGPT guest-authentication, adapter headless-policy, versioned manifest-schema validation, and Windows profile-lock regressions.
- Adapter contract tests that do not require live provider accounts.
- API/SSE integration tests.
- SQLite migration and recovery tests.
- Path, profile, sanitization, and external-effect safety tests.
- Source distribution and wheel build.
- Wheel installation into an isolated target directory using the build environment's already-installed runtime dependencies.
- CLI import/help and setup dry-run validation from that installed wheel target.

## Environment-limited validation

A fully dependency-resolving fresh virtual-environment install could not be completed because this environment's package index did not expose the required FastAPI distribution. Wheel contents and imports are therefore validated against an isolated wheel target while reusing the build environment's installed dependencies.

The controlled Chromium integration test is included but could not be executed in this build environment because Playwright Chromium was not already installed and the environment could not resolve Playwright/Microsoft download hosts during `playwright install chromium`.

The live ChatGPT, Gemini, and DeepSeek smoke tests are included but are intentionally supervised and require manually authenticated persistent profiles. They were not run in this build environment because no authenticated provider profiles were supplied.

Accordingly, provider rule sets and selectors remain implementation candidates until supervised live smoke testing; v1.0.1 specifically fixes the observed ChatGPT anonymous-composer authentication false positive, but a stable release should still run the documented supervised smoke matrix before publication.

## Required release-gate commands

See `docs/RUNBOOK.md` and `scripts/release_check.py` for the complete operational release procedure.


## v1.0.2 live finding incorporated

A real Windows/ChatGPT profile authenticated successfully in visible Playwright Chromium while the same profile returned a false negative under headless verification. v1.0.2 therefore treats headless authentication verification and headless execution as explicit adapter capabilities instead of assumptions.
