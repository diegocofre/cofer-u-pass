from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path
from typing import Any

import typer
import uvicorn

from cofer_u_pass.application.service import ApplicationService
from cofer_u_pass.config.settings import (
    default_config_path,
    load_config,
    sanitized_snapshot,
    setup_files,
    rotate_api_token,
)
from cofer_u_pass.domain.models import ConversationMode

app = typer.Typer(no_args_is_help=True, help="Cofer U Pass local automation engine")
profiles_app = typer.Typer(no_args_is_help=True, help="Manage persistent browser profiles")
config_app = typer.Typer(no_args_is_help=True, help="Inspect configuration")
diagnostics_app = typer.Typer(no_args_is_help=True, help="Inspect and export diagnostic evidence")
app.add_typer(profiles_app, name="profiles")
app.add_typer(config_app, name="config")
app.add_typer(diagnostics_app, name="diagnostics")


def _current_version() -> str:
    import importlib.metadata
    try:
        return importlib.metadata.version("cofer-u-pass")
    except importlib.metadata.PackageNotFoundError:
        from cofer_u_pass import __version__
        return __version__


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(_current_version())
        raise typer.Exit()


@app.callback()
def root_callback(
    version: bool = typer.Option(
        False,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show the installed Cofer U Pass version and exit.",
    ),
) -> None:
    del version


def arun(coro):
    return asyncio.run(coro)


def emit(value: Any, json_output: bool = False) -> None:
    if hasattr(value, "model_dump"):
        value = value.model_dump(mode="json")
    if json_output:
        typer.echo(json.dumps(value, ensure_ascii=False, default=str))
    elif isinstance(value, (dict, list)):
        typer.echo(json.dumps(value, ensure_ascii=False, indent=2, default=str))
    else:
        typer.echo(str(value))


def parse_inputs(items: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for item in items:
        if "=" not in item:
            raise typer.BadParameter(f"input must be key=value: {item}")
        key, raw = item.split("=", 1)
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            value = raw
        result[key] = value
    return result


@app.command()
def setup(dry_run: bool = typer.Option(False, "--dry-run"), skip_browser: bool = typer.Option(False, help="Skip Chromium installation (advanced/offline use).")):
    """Create local configuration/data storage, initialize SQLite, and install managed Chromium."""
    changes = setup_files(dry_run=dry_run)
    cfg = load_config()
    if dry_run:
        emit({"dry_run": True, "changes": changes, "chromium": "would install" if not skip_browser else "skipped"})
        return
    async def work():
        service = ApplicationService(cfg)
        await service.start(execute_queued=False)
        ok, detail = await service.db.integrity_check()
        return ok, detail
    ok, detail = arun(work())
    if not skip_browser:
        proc = subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)
        if proc.returncode != 0:
            raise typer.Exit(proc.returncode)
    emit({"status": "ok" if ok else "failed", "changes": changes, "sqlite": detail, "next": "Create a profile with: cofer-u-pass profiles create NAME --provider chatgpt"})


@app.command()
def doctor(json_output: bool = typer.Option(False, "--json"), run_id: str | None = typer.Option(None, help="Create a sanitized diagnostic package for a run.")):
    async def work():
        cfg = load_config()
        service = ApplicationService(cfg)
        await service.start(execute_queued=False)
        if run_id:
            run = await service.get_run(run_id)
            path = await service.doctor.capture_basic(run_id, run.error_class.value if run.error_class else "manual", run.error_message or "manual diagnostic capture")
            return {"package": path, "inventory": service.doctor.inventory(Path(path))}
        checks = await service.doctor.preventive()
        return {"ok": all(c["ok"] for c in checks), "checks": checks}
    result = arun(work())
    emit(result, json_output)
    if not result.get("ok", True):
        raise typer.Exit(1)


@app.command()
def serve(host: str | None = typer.Option(None), port: int | None = typer.Option(None)):
    """Run the loopback HTTP/SSE API in the foreground."""
    cfg = load_config(explicit={"api": {**({"host": host} if host else {}), **({"port": port} if port else {})}})
    if cfg.api.host not in {"127.0.0.1", "::1", "localhost"}:
        raise typer.BadParameter("v1 API can bind only to loopback")
    from cofer_u_pass.api.app import create_app
    uvicorn.run(create_app(cfg), host=cfg.api.host, port=cfg.api.port, log_level=cfg.log_level.lower())


@app.command("run")
def run_protocol(
    protocol: Path,
    profile: str = typer.Option(..., "--profile"),
    input_values: list[str] = typer.Option([], "--input", help="Protocol input as key=value; repeatable."),
    conversation_mode: ConversationMode = typer.Option(ConversationMode.NEW, "--conversation-mode"),
    conversation_id: str | None = typer.Option(None, "--conversation-id"),
    client_request_id: str | None = typer.Option(None, "--client-request-id"),
    json_output: bool = typer.Option(False, "--json"),
):
    async def work():
        service = ApplicationService(load_config())
        await service.start(execute_queued=True)
        run = await service.create_run(
            protocol, profile_id=profile, inputs=parse_inputs(input_values), conversation_mode=conversation_mode,
            conversation_id=conversation_id, client_request_id=client_request_id,
        )
        last = 0
        while True:
            events = await service.db.get_events(run.run_id, last)
            for event in events:
                last = event.sequence
                if json_output:
                    typer.echo(event.model_dump_json())
                else:
                    if event.type == "response.delta":
                        continue
                    typer.echo(f"[{event.sequence:04d}] {event.type}")
            current = await service.get_run(run.run_id)
            if current.state.value in {"completed", "cancelled", "failed", "authentication_required", "recoverable", "outcome_unknown"}:
                await service.wait_for_execution_cleanup(run.run_id)
                current = await service.get_run(run.run_id)
                result = await service.db.get_result(run.run_id)
                return {"run": current.model_dump(mode="json"), "result": result.model_dump(mode="json") if result else None}
            await asyncio.sleep(0.2)
    emit(arun(work()), json_output)


@app.command()
def status(run_id: str, json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.get_run(run_id)
    emit(arun(work()), json_output)


@app.command()
def stream(run_id: str, after: int = typer.Option(0, help="Start after this persisted event sequence."), json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False)
        seq = after
        terminal = {"completed", "cancelled", "failed", "authentication_required", "recoverable", "outcome_unknown"}
        while True:
            batch = await s.db.get_events(run_id, seq)
            for ev in batch:
                seq = ev.sequence
                emit(ev, json_output)
            run = await s.get_run(run_id)
            if run.state.value in terminal and not batch:
                return
            await asyncio.sleep(0.2)
    arun(work())


@app.command()
def cancel(run_id: str, json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.cancel_run(run_id)
    emit(arun(work()), json_output)


@app.command()
def resume(run_id: str, json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.resume_run(run_id)
    emit(arun(work()), json_output)


@app.command("resolve-outcome")
def resolve_outcome(run_id: str, action_id: str = typer.Option(..., "--action"), effect: str = typer.Option(..., help="occurred or not-occurred"), json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.resolve_outcome(run_id, action_id, effect=effect)
    emit(arun(work()), json_output)


@app.command("import-conversation")
def import_conversation(profile: str = typer.Option(..., "--profile"), url: str = typer.Argument(...)):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.import_conversation(profile, url)
    emit({"conversation_id": arun(work())})


@profiles_app.command("create")
def profile_create(name: str, provider: str = typer.Option(..., "--provider"), json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.create_profile(name, provider)
    emit(arun(work()), json_output)


@profiles_app.command("authenticate")
def profile_authenticate(name: str, timeout: float = typer.Option(900, help="Seconds to wait for manual login recognition."), json_output: bool = typer.Option(False, "--json")):
    typer.echo("A visible managed Chromium window will open. Complete login/MFA/CAPTCHA manually; Cofer U Pass only recognizes the authenticated state.")
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.authenticate_profile(name, timeout_seconds=timeout)
    emit(arun(work()), json_output)


@profiles_app.command("status")
def profile_status(name: str, verify: bool = typer.Option(False, "--verify"), json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.profile_status(name, verify=verify)
    emit(arun(work()), json_output)


@profiles_app.command("list")
def profile_list(json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.list_profiles()
    emit([p.model_dump(mode="json") for p in arun(work())], json_output)


@config_app.command("paths")
def config_paths():
    cfg = load_config()
    emit({"config": str(default_config_path()), "data_root": str(cfg.data_path), "database": str(cfg.db_path), "profiles": str(cfg.profiles_path), "artifacts": str(cfg.artifacts_path), "evidence": str(cfg.evidence_path), "backups": str(cfg.backups_path)})


@config_app.command("validate")
def config_validate():
    cfg = load_config()
    emit({"status": "ok", "schema_version": cfg.schema_version})


@config_app.command("rotate-token")
def config_rotate_token():
    cfg = load_config()
    path = rotate_api_token(cfg)
    emit({"status": "rotated", "token_file": str(path), "next": "Restart cofer-u-pass serve before using the new token."})


@config_app.command("show")
def config_show(effective: bool = typer.Option(True, "--effective/--raw"), profile: str | None = typer.Option(None, "--profile"), json_output: bool = typer.Option(False, "--json")):
    cfg = load_config()
    data = sanitized_snapshot(cfg)
    if profile:
        data["selected_profile"] = profile
    emit(data, json_output)


@diagnostics_app.command("inventory")
def diagnostics_inventory(package_dir: Path):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return s.doctor.inventory(package_dir)
    emit(arun(work()))


@diagnostics_app.command("export")
def diagnostics_export(package_dir: Path, output: Path = typer.Option(..., "--output")):
    typer.echo("Export includes only the files shown by `cofer-u-pass diagnostics inventory`. Review that inventory before sharing the ZIP.")
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return s.doctor.export(package_dir, output)
    emit({"zip": str(arun(work()))})


def _latest_version() -> str:
    with urllib.request.urlopen("https://pypi.org/pypi/cofer-u-pass/json", timeout=10) as response:
        return json.load(response)["info"]["version"]


@app.command("cleanup")
def cleanup(apply: bool = typer.Option(False, "--apply", help="Apply the displayed retention cleanup plan."), json_output: bool = typer.Option(False, "--json")):
    async def work():
        s = ApplicationService(load_config()); await s.start(execute_queued=False); return await s.cleanup(apply=apply)
    plan = arun(work())
    emit(plan, json_output)
    if not apply:
        typer.echo("Dry-run only. Re-run with --apply to perform this exact class of conservative cleanup.")


@app.command("update")
def update_command(check: bool = typer.Option(False, "--check", help="Only check whether a newer package exists.")):
    if check:
        latest = _latest_version()
        current = _current_version()
        emit({"current": current, "latest": latest, "update_available": latest != current})
        return

    async def preflight():
        s = ApplicationService(load_config()); await s.start(execute_queued=False)
        if await s.db.has_active_runs():
            raise RuntimeError("active runs exist; cancel or complete them before updating")
        ok, detail = await s.db.integrity_check()
        if not ok:
            raise RuntimeError(f"SQLite integrity failed: {detail}")
        backup = await s.db.create_backup(s.config.backups_path)
        return backup
    backup = arun(preflight())
    typer.echo(f"Database backup created: {backup}")
    if shutil.which("uv"):
        cmd = ["uv", "tool", "upgrade", "cofer-u-pass"]
    elif shutil.which("pipx"):
        cmd = ["pipx", "upgrade", "cofer-u-pass"]
    else:
        raise typer.BadParameter("Neither uv nor pipx was found. Install the desired pinned version explicitly.")
    proc = subprocess.run(cmd, check=False)
    if proc.returncode != 0:
        typer.echo(f"Update failed. Database backup remains at {backup}", err=True)
        raise typer.Exit(proc.returncode)
    typer.echo("Package manager update completed. Run `cofer-u-pass setup` and `cofer-u-pass doctor` before the next run.")


def main() -> None:
    app()
