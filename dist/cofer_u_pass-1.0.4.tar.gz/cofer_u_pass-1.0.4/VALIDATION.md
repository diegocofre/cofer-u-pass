# Validation Report — v1.0.4

Validation date: 2026-07-26

## Completed in this build environment

- Deterministic/unit/contract/integration tests: 32 passed, 2 skipped. Coverage includes ChatGPT guest-authentication, adapter headless-policy, versioned manifest-schema validation, and Windows profile-lock regressions.
- Adapter contract tests that do not require live provider accounts.
- API/SSE integration tests.
- SQLite migration and recovery tests.
- Path, profile, sanitization, and external-effect safety tests.
- Source distribution and wheel build.
- Wheel installation into an isolated target directory using the build environment's already-installed runtime dependencies.
- CLI import/help and setup dry-run validation from that installed wheel target.

## Environment-limited validation

A fully dependency-resolving fresh virtual-environment install could not be completed because this environment's package index did not expose the required FastAPI distribution. Wheel contents and imports are therefore validated against an isolated wheel target while reusing the build environment's installed dependencies.

The controlled Chromium integration test is included but could not be executed in this build environment because Playwright Chromium was not already installed and the environment could not resolve Playwright/Microsoft download hosts during `playwright install chromium`.

The live ChatGPT, Gemini, and DeepSeek smoke tests are included but are intentionally supervised and require manually authenticated persistent profiles. They were not run in this build environment because no authenticated provider profiles were supplied.

Accordingly, provider rule sets and selectors remain implementation candidates until supervised live smoke testing; v1.0.1 fixes the observed ChatGPT anonymous-composer authentication false positive; v1.0.2 fixes visible/headless verification policy and Windows lock handling; v1.0.3 fixes delayed authenticated-UI verification; v1.0.4 extends that same bounded authentication wait to run preflight and adds an executor-cleanup barrier for CLI shutdown. A stable release should still run the documented supervised smoke matrix before publication.

## Required release-gate commands

See `docs/RUNBOOK.md` and `scripts/release_check.py` for the complete operational release procedure.


## v1.0.2 live finding incorporated

A real Windows/ChatGPT profile authenticated successfully in visible Playwright Chromium while the same profile returned a false negative under headless verification. v1.0.2 therefore treats headless authentication verification and headless execution as explicit adapter capabilities instead of assumptions.


## v1.0.3 live finding incorporated

A real Windows/ChatGPT persistent profile was demonstrably authenticated and recognized by the interactive visible authentication flow, while `profiles status --verify` still returned a false negative. Code inspection showed that authentication waits and polls, whereas status verification performed one immediate check after `DOMContentLoaded`. v1.0.3 adds a bounded positive-signal grace period and a regression test for delayed authenticated UI mounting.


## v1.0.4 live finding incorporated

A real Windows/ChatGPT run entered `authentication_required` immediately after `profiles status --verify` had confirmed the same persistent profile as `ready` and authenticated. The run log showed the failure occurred before `open_conversation` or any external-effect action. Code inspection confirmed run preflight still performed a one-shot authentication check after `DOMContentLoaded`. The same run also exposed Windows/Python 3.13 Playwright subprocess transport warnings because the CLI returned as soon as public state became terminal, before the executor `finally` block completed browser/process cleanup. v1.0.4 centralizes bounded authentication polling and makes the CLI wait for executor cleanup before returning.
