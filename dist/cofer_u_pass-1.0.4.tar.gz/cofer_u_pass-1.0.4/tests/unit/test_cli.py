import importlib

from typer.testing import CliRunner

cli_module = importlib.import_module("cofer_u_pass.cli.app")


def test_root_version_option(monkeypatch):
    monkeypatch.setattr(cli_module, "_current_version", lambda: "1.0.4")
    result = CliRunner().invoke(cli_module.app, ["--version"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "1.0.4"
